#import "settings.typ": addToPDFBookmark
#set page(margin: 1.5in)
#place(center + horizon)[
  #addToPDFBookmark("Acknowledgment")
  #text(size: 20pt)[*Acknowledgment*]

  The satisfaction that accompanies the successful completion of the project would be incomplete without the mention of the people who made it possible. We consider ourself privileged to express gratitude and respect towards all those who guided us through the completion of this project. We express our indebtedness in God Almighty for the successful completion of our project. First and foremost, we express our sincerest regards to our project guides, Unni A M, Mumthaz and Krishnapriya C V for their valuable inputs, guidance cooperation and constructive criticism throughout the duration of our project. We deeply express our sincere thanks to our Head of Department, Dr. Deepa Sankar for encouraging and allowing us to present the project at our department premises. We take this opportunity to thank all our lecturers who directly or indirectly helped our project. We pay respect and love to our parents and all other family members and friends for their love and encouragement throughout our career. Last but not the least we express our thanks to our friends for their cooperation and support
]
#pagebreak()
